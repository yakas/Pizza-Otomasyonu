﻿namespace Pizza_Otomasyonu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Pizzalar pizza;

        private void Form1_Load(object sender, EventArgs e)
        {
            Ebat kucuk = new Ebat { Ebatlar = "Küçük", Carpan = 1.0m };
            Ebat orta = new Ebat { Ebatlar = "Orta", Carpan = 1.25m };
            Ebat buyuk = new Ebat { Ebatlar = "Büyük", Carpan = 1.75m };
            Ebat maxi = new Ebat { Ebatlar = "Maxi", Carpan = 2.0m };

            cmbEbat.Items.Add(kucuk);
            cmbEbat.Items.Add(orta);
            cmbEbat.Items.Add(buyuk);
            cmbEbat.Items.Add(maxi);

            Pizzalar klasik = new Pizzalar { Adi = "KLASİK", Fiyat = 14m };
            Pizzalar karisik = new Pizzalar { Adi = "KARIŞIK", Fiyat = 17m };
            Pizzalar extravaganza = new Pizzalar { Adi = "EXTRAVAGANZA", Fiyat = 21m };
            Pizzalar italiano = new Pizzalar { Adi = "ITALIANO", Fiyat = 20m };
            Pizzalar turkish = new Pizzalar { Adi = "TURKISH", Fiyat = 23m };
            Pizzalar tuna = new Pizzalar { Adi = "TUNA", Fiyat = 18m };
            Pizzalar seafeed = new Pizzalar { Adi = "SEAFEED", Fiyat = 19m };
            Pizzalar kastamonu = new Pizzalar { Adi = "KASTAMONU", Fiyat = 20m };
            Pizzalar calypso = new Pizzalar { Adi = "CALYPSO", Fiyat = 24m };
            Pizzalar akdeniz = new Pizzalar { Adi = "AKDENİZ", Fiyat = 21m };
            Pizzalar karadeniz = new Pizzalar { Adi = "KARADENİZ", Fiyat = 21m };


            lstboxPizzalar.Items.Add(klasik);
            lstboxPizzalar.Items.Add(karisik);
            lstboxPizzalar.Items.Add(extravaganza);
            lstboxPizzalar.Items.Add(italiano);
            lstboxPizzalar.Items.Add(turkish);
            lstboxPizzalar.Items.Add(tuna);
            lstboxPizzalar.Items.Add(seafeed);
            lstboxPizzalar.Items.Add(kastamonu);
            lstboxPizzalar.Items.Add(calypso);
            lstboxPizzalar.Items.Add(akdeniz);
            lstboxPizzalar.Items.Add(karadeniz);


        }
        string kenar = "ince kenar";
        string malz = "";
        decimal toplamTutar = 0m;
        private void btnHesapla_Click(object sender, EventArgs e)
        {
            try
            {

                pizza = (Pizzalar)lstboxPizzalar.SelectedItem;

                Ebat ebat;
                ebat = (Ebat)cmbEbat.SelectedItem;

                decimal tutar = ebat.Carpan * pizza.Fiyat;


                if (rbtnKalinKenar.Checked)
                {
                    tutar += 2;
                    kenar = "kalın kenar";
                }

                tutar *= nmrAdet.Value;

                txtTutar.Text = tutar.ToString();
                toplamTutar += tutar;

                foreach (CheckBox checkBox in groupBox1.Controls)
                {
                    if (checkBox.Checked)
                    {
                        malz += checkBox.Text + ",";
                    }
                }


            }
            catch (NullReferenceException)
            {

                MessageBox.Show("Ebat seçimi yapmadınız !");
            }



        }
        int siparis = 0;
        private void btnSepeteEkle_Click(object sender, EventArgs e)
        {
            string sepet = "";
            sepet = $"{cmbEbat.Text} - {lstboxPizzalar.SelectedItem.ToString()} - {kenar} - {malz} - {nmrAdet.Value}x{txtTutar.Text}";

            lstboxSepet.Items.Add(sepet);
            label6.Text=txtTutar.Text;
            siparis++;
        }

        private void btnSiparisiOnayla_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"Sipariş Adeti= {siparis} - Toplam Tutar= {toplamTutar}");
        }

        private void btnSepetiSil_Click(object sender, EventArgs e)
        {


            cmbEbat.SelectedIndex = -1;
            lstboxPizzalar.SelectedIndex = -1;
            lstboxSepet.Items.Clear();
            txtTutar.Text = string.Empty;
            nmrAdet.Value = 0;
            foreach (CheckBox checkBox in groupBox1.Controls)
            {
                checkBox.Checked = false;
            }
            rbtnInceKenar.Checked = true;
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
