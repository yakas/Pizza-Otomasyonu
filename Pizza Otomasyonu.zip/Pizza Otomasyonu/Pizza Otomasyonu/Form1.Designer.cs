﻿namespace Pizza_Otomasyonu
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            cmbEbat = new ComboBox();
            lstboxPizzalar = new ListBox();
            label2 = new Label();
            rbtnInceKenar = new RadioButton();
            rbtnKalinKenar = new RadioButton();
            groupBox1 = new GroupBox();
            checkBox6 = new CheckBox();
            checkBox7 = new CheckBox();
            checkBox8 = new CheckBox();
            checkBox9 = new CheckBox();
            checkBox10 = new CheckBox();
            checkBox5 = new CheckBox();
            checkBox4 = new CheckBox();
            checkBox3 = new CheckBox();
            checkBox2 = new CheckBox();
            checkBox1 = new CheckBox();
            label3 = new Label();
            nmrAdet = new NumericUpDown();
            btnHesapla = new Button();
            lstboxSepet = new ListBox();
            label4 = new Label();
            txtTutar = new TextBox();
            btnSepeteEkle = new Button();
            label5 = new Label();
            label6 = new Label();
            btnSiparisiOnayla = new Button();
            btnSepetiSil = new Button();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nmrAdet).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label1.Location = new Point(38, 53);
            label1.Name = "label1";
            label1.Size = new Size(31, 15);
            label1.TabIndex = 0;
            label1.Text = "Ebat";
            // 
            // cmbEbat
            // 
            cmbEbat.FormattingEnabled = true;
            cmbEbat.Location = new Point(38, 71);
            cmbEbat.Name = "cmbEbat";
            cmbEbat.Size = new Size(121, 23);
            cmbEbat.TabIndex = 1;
            // 
            // lstboxPizzalar
            // 
            lstboxPizzalar.FormattingEnabled = true;
            lstboxPizzalar.ItemHeight = 15;
            lstboxPizzalar.Location = new Point(38, 119);
            lstboxPizzalar.Name = "lstboxPizzalar";
            lstboxPizzalar.Size = new Size(121, 94);
            lstboxPizzalar.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label2.Location = new Point(40, 101);
            label2.Name = "label2";
            label2.Size = new Size(49, 15);
            label2.TabIndex = 0;
            label2.Text = "Pizzalar";
            // 
            // rbtnInceKenar
            // 
            rbtnInceKenar.AutoSize = true;
            rbtnInceKenar.Checked = true;
            rbtnInceKenar.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            rbtnInceKenar.Location = new Point(38, 231);
            rbtnInceKenar.Name = "rbtnInceKenar";
            rbtnInceKenar.Size = new Size(83, 19);
            rbtnInceKenar.TabIndex = 3;
            rbtnInceKenar.TabStop = true;
            rbtnInceKenar.Text = "ince kenar";
            rbtnInceKenar.UseVisualStyleBackColor = true;
            // 
            // rbtnKalinKenar
            // 
            rbtnKalinKenar.AutoSize = true;
            rbtnKalinKenar.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            rbtnKalinKenar.Location = new Point(38, 256);
            rbtnKalinKenar.Name = "rbtnKalinKenar";
            rbtnKalinKenar.Size = new Size(86, 19);
            rbtnKalinKenar.TabIndex = 3;
            rbtnKalinKenar.Text = "kalın kenar";
            rbtnKalinKenar.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Turquoise;
            groupBox1.Controls.Add(checkBox6);
            groupBox1.Controls.Add(checkBox7);
            groupBox1.Controls.Add(checkBox8);
            groupBox1.Controls.Add(checkBox9);
            groupBox1.Controls.Add(checkBox10);
            groupBox1.Controls.Add(checkBox5);
            groupBox1.Controls.Add(checkBox4);
            groupBox1.Controls.Add(checkBox3);
            groupBox1.Controls.Add(checkBox2);
            groupBox1.Controls.Add(checkBox1);
            groupBox1.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            groupBox1.Location = new Point(38, 286);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(216, 156);
            groupBox1.TabIndex = 4;
            groupBox1.TabStop = false;
            groupBox1.Text = "Malzemeler";
            // 
            // checkBox6
            // 
            checkBox6.AutoSize = true;
            checkBox6.Location = new Point(121, 122);
            checkBox6.Name = "checkBox6";
            checkBox6.Size = new Size(61, 19);
            checkBox6.TabIndex = 15;
            checkBox6.Text = "Peynir";
            checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            checkBox7.AutoSize = true;
            checkBox7.Location = new Point(121, 97);
            checkBox7.Name = "checkBox7";
            checkBox7.Size = new Size(79, 19);
            checkBox7.TabIndex = 16;
            checkBox7.Text = "Ton Balığı";
            checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            checkBox8.AutoSize = true;
            checkBox8.Location = new Point(121, 72);
            checkBox8.Name = "checkBox8";
            checkBox8.Size = new Size(66, 19);
            checkBox8.TabIndex = 17;
            checkBox8.Text = "Mantar";
            checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            checkBox9.AutoSize = true;
            checkBox9.Location = new Point(121, 47);
            checkBox9.Name = "checkBox9";
            checkBox9.Size = new Size(60, 19);
            checkBox9.TabIndex = 18;
            checkBox9.Text = "Sucuk";
            checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            checkBox10.AutoSize = true;
            checkBox10.Location = new Point(121, 22);
            checkBox10.Name = "checkBox10";
            checkBox10.Size = new Size(59, 19);
            checkBox10.TabIndex = 19;
            checkBox10.Text = "Salam";
            checkBox10.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            checkBox5.AutoSize = true;
            checkBox5.Location = new Point(6, 122);
            checkBox5.Name = "checkBox5";
            checkBox5.Size = new Size(61, 19);
            checkBox5.TabIndex = 14;
            checkBox5.Text = "Zeytin";
            checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            checkBox4.AutoSize = true;
            checkBox4.Location = new Point(6, 97);
            checkBox4.Name = "checkBox4";
            checkBox4.Size = new Size(68, 19);
            checkBox4.TabIndex = 14;
            checkBox4.Text = "Anquez";
            checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.Location = new Point(6, 72);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(53, 19);
            checkBox3.TabIndex = 14;
            checkBox3.Text = "Mısır";
            checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Location = new Point(6, 47);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(53, 19);
            checkBox2.TabIndex = 14;
            checkBox2.Text = "Sosis";
            checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(6, 22);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(100, 19);
            checkBox1.TabIndex = 14;
            checkBox1.Text = "Dana Jambon";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label3.Location = new Point(28, 461);
            label3.Name = "label3";
            label3.Size = new Size(37, 15);
            label3.TabIndex = 5;
            label3.Text = "Adet:";
            // 
            // nmrAdet
            // 
            nmrAdet.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            nmrAdet.Location = new Point(71, 459);
            nmrAdet.Name = "nmrAdet";
            nmrAdet.Size = new Size(62, 23);
            nmrAdet.TabIndex = 5;
            // 
            // btnHesapla
            // 
            btnHesapla.BackColor = Color.Red;
            btnHesapla.ForeColor = Color.White;
            btnHesapla.Location = new Point(38, 515);
            btnHesapla.Name = "btnHesapla";
            btnHesapla.Size = new Size(95, 37);
            btnHesapla.TabIndex = 6;
            btnHesapla.Text = "Hesapla";
            btnHesapla.UseVisualStyleBackColor = false;
            btnHesapla.Click += btnHesapla_Click;
            // 
            // lstboxSepet
            // 
            lstboxSepet.FormattingEnabled = true;
            lstboxSepet.HorizontalScrollbar = true;
            lstboxSepet.ItemHeight = 15;
            lstboxSepet.Location = new Point(285, 101);
            lstboxSepet.Name = "lstboxSepet";
            lstboxSepet.Size = new Size(596, 319);
            lstboxSepet.TabIndex = 8;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label4.Location = new Point(143, 526);
            label4.Name = "label4";
            label4.Size = new Size(39, 15);
            label4.TabIndex = 9;
            label4.Text = "Tutar:";
            // 
            // txtTutar
            // 
            txtTutar.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            txtTutar.Location = new Point(183, 523);
            txtTutar.Name = "txtTutar";
            txtTutar.Size = new Size(104, 23);
            txtTutar.TabIndex = 10;
            // 
            // btnSepeteEkle
            // 
            btnSepeteEkle.BackColor = Color.RoyalBlue;
            btnSepeteEkle.FlatStyle = FlatStyle.Flat;
            btnSepeteEkle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnSepeteEkle.ForeColor = Color.White;
            btnSepeteEkle.Location = new Point(285, 460);
            btnSepeteEkle.Name = "btnSepeteEkle";
            btnSepeteEkle.Size = new Size(105, 36);
            btnSepeteEkle.TabIndex = 7;
            btnSepeteEkle.Text = "Sepete Ekle";
            btnSepeteEkle.UseVisualStyleBackColor = false;
            btnSepeteEkle.Click += btnSepeteEkle_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label5.Location = new Point(706, 426);
            label5.Name = "label5";
            label5.Size = new Size(82, 15);
            label5.TabIndex = 12;
            label5.Text = "Toplam Tutar:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label6.Location = new Point(791, 426);
            label6.Name = "label6";
            label6.Size = new Size(39, 15);
            label6.TabIndex = 12;
            label6.Text = " - - - -";
            // 
            // btnSiparisiOnayla
            // 
            btnSiparisiOnayla.BackColor = Color.Lime;
            btnSiparisiOnayla.FlatStyle = FlatStyle.Flat;
            btnSiparisiOnayla.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnSiparisiOnayla.ForeColor = Color.White;
            btnSiparisiOnayla.Location = new Point(704, 460);
            btnSiparisiOnayla.Name = "btnSiparisiOnayla";
            btnSiparisiOnayla.Size = new Size(105, 37);
            btnSiparisiOnayla.TabIndex = 8;
            btnSiparisiOnayla.Text = "Siparişi Onayla";
            btnSiparisiOnayla.UseVisualStyleBackColor = false;
            btnSiparisiOnayla.Click += btnSiparisiOnayla_Click;
            // 
            // btnSepetiSil
            // 
            btnSepetiSil.BackColor = Color.DeepPink;
            btnSepetiSil.FlatStyle = FlatStyle.Flat;
            btnSepetiSil.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnSepetiSil.ForeColor = Color.White;
            btnSepetiSil.Location = new Point(491, 459);
            btnSepetiSil.Name = "btnSepetiSil";
            btnSepetiSil.Size = new Size(105, 37);
            btnSepetiSil.TabIndex = 9;
            btnSepetiSil.Text = "Sepeti Sil";
            btnSepetiSil.UseVisualStyleBackColor = false;
            btnSepetiSil.Click += btnSepetiSil_Click;
            // 
            // label7
            // 
            label7.BackColor = Color.DeepSkyBlue;
            label7.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            label7.Location = new Point(-1, -1);
            label7.Name = "label7";
            label7.Size = new Size(907, 48);
            label7.TabIndex = 15;
            label7.Text = "PİZZA SİPARİŞ";
            label7.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Red;
            label8.FlatStyle = FlatStyle.Flat;
            label8.Font = new Font("Segoe UI", 12F);
            label8.Location = new Point(874, 9);
            label8.Name = "label8";
            label8.Size = new Size(19, 21);
            label8.TabIndex = 16;
            label8.Text = "X";
            label8.Click += label8_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label9.Location = new Point(285, 79);
            label9.Name = "label9";
            label9.Size = new Size(40, 15);
            label9.TabIndex = 17;
            label9.Text = "Sepet";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkTurquoise;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(905, 597);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(btnSepetiSil);
            Controls.Add(btnSiparisiOnayla);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(btnSepeteEkle);
            Controls.Add(txtTutar);
            Controls.Add(label4);
            Controls.Add(lstboxSepet);
            Controls.Add(btnHesapla);
            Controls.Add(nmrAdet);
            Controls.Add(label3);
            Controls.Add(groupBox1);
            Controls.Add(rbtnKalinKenar);
            Controls.Add(rbtnInceKenar);
            Controls.Add(lstboxPizzalar);
            Controls.Add(cmbEbat);
            Controls.Add(label2);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nmrAdet).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private ComboBox cmbEbat;
        private ListBox lstboxPizzalar;
        private Label label2;
        private RadioButton rbtnInceKenar;
        private RadioButton rbtnKalinKenar;
        private GroupBox groupBox1;
        private Label label3;
        private NumericUpDown nmrAdet;
        private Button btnHesapla;
        private ListBox lstboxSepet;
        private Label label4;
        private TextBox txtTutar;
        private Button btnSepeteEkle;
        private Label label5;
        private Label label6;
        private Button btnSiparisiOnayla;
        private CheckBox checkBox6;
        private CheckBox checkBox7;
        private CheckBox checkBox8;
        private CheckBox checkBox9;
        private CheckBox checkBox10;
        private CheckBox checkBox5;
        private CheckBox checkBox4;
        private CheckBox checkBox3;
        private CheckBox checkBox2;
        private CheckBox checkBox1;
        private Button btnSepetiSil;
        private Label label7;
        private Label label8;
        private Label label9;
    }
}
