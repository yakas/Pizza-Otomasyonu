﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizza_Otomasyonu
{
    public class Ebat
    {
        public string Ebatlar { get; set; }
        public decimal Carpan { get; set; }
       
        public override string ToString()
        {
            return Ebatlar;
        }

       
    }
}
