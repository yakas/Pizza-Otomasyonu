﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizza_Otomasyonu
{
    public  class KenarTipi
    {
        public string Kenar { get; set; }
        public int EkFiyat { get; set; }
    }
}
