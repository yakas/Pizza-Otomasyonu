﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizza_Otomasyonu
{
    public class Pizzalar
    {
        public string Adi { get; set; }
        public decimal Fiyat { get; set; }
        public Ebat Ebat { get; set; }
        public KenarTipi KenarTipi { get; set; }
        public List<string> Malzemeler { get; set; }

        public override string ToString()
        {
            return Adi;
        }
        

    }
}
